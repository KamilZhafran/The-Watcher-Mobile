package com.example.the_watcher

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
