import 'constants.dart';

class CustomColor {
  static const primaryColor = Color.fromARGB(255, 255, 165, 0);
  static const secondaryColor = Color.fromARGB(255, 247, 236, 224);
  static const color30 = Color.fromARGB(255, 30, 30, 30);
}