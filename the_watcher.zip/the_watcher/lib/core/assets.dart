class ImageAssets {
  static const splash = 'assets/splash.png';
  static const person = 'assets/person.png';
  static const personHalf = 'assets/person_half.png';
  static const alert = 'assets/alert.png';
}